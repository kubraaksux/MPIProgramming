# MPIProgramming
Digital Twin implementation - a parallel algorithm creation to simulate a factory


Requirements: 
    python -m pip install mpi4py
    python -m pip install numpy 


Command: mpiexec -oversubscribe -n 1 python mpi_baturhan.py input.txt output.txt 